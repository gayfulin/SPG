#program launcher
cp out out_prev
main.exe 1>out 2>err
